You can connect us with discor, we will send you the preview version.  - FewBox Team
https://discord.gg/DXUDTHaScC