import * as _Embedded from './src/embedded';
import * as _Component from './src/component';
import * as _Util from './src/util';
export declare namespace DenFigma {
    const Component: typeof _Component;
    const Util: typeof _Util;
    export import DSL = _Embedded.DSL;
    export import DSLCategory = _Embedded.DSLCategory;
    export import DSLJSX = _Embedded.DSLJSX;
    export import DSLInvisiable = _Embedded.DSLInvisiable;
    export import DSLGroup = _Embedded.DSLGroup;
    export import DSLPart = _Embedded.DSLPart;
    export import DSLReference = _Embedded.DSLReference;
    export import DSLLayout = _Embedded.DSLLayout;
    export import DSLImage = _Embedded.DSLImage;
    export import DSLSvg = _Embedded.DSLSvg;
    export import DSLOther = _Embedded.DSLOther;
    export import DSLText = _Embedded.DSLText;
    export import DSLShapeRectangle = _Embedded.DSLShapeRectangle;
    export import DSLShapeEllipse = _Embedded.DSLShapeEllipse;
    export import DSLTodo = _Embedded.DSLTodo;
    export import DSLAllType = _Embedded.DSLAllType;
    export import HashImageMap = _Embedded.HashImageMap;
    export import VectorSvgMap = _Embedded.VectorSvgMap;
    export import LayoutCategory = _Embedded.LayoutCategory;
    export import XLayoutType = _Embedded.XLayoutType;
    export import YLayoutType = _Embedded.YLayoutType;
}
