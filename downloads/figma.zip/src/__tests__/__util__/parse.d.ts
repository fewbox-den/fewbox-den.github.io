import { DenFigma } from '../../..';
export declare const verifyParse: (dsl: DenFigma.DSLAllType, toBe: string) => any;
