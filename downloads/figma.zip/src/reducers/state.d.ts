import { GuideKeyType } from '../figma/guideStepKey';
import { DSL } from '../figma/dsl/type';
import { AutoSizeSetting, LayoutChildrenSetting, LayoutSetting, PositionSetting } from '../figma/type';
export interface List<T> {
    items: T[];
}
export interface Paging<T> {
    items: T[];
    itemCount: number;
    pageCount: number;
    pageRange: number;
    pageIndex: number;
}
export interface AppSettings {
    PROTOCOL: string;
    HOST: string;
    BASEPATH?: string;
    PORT: string;
}
export interface Store {
    master: Master;
    setting: Setting;
    ajax: Ajax;
    design: Design;
}
export interface Master {
    currentPath?: string;
    isAlertVisiable: boolean;
    alertMessage: string;
    guideKey: GuideKeyType;
}
export interface Ajax {
    httpbinResponse: HttpbinResponse;
    props: string[];
    code: string;
}
export interface Design {
    layoutSetting: LayoutSetting;
    layoutChildrenSetting: LayoutChildrenSetting;
    positionSetting: PositionSetting;
    autoSizeSetting: AutoSizeSetting;
    isSvg: boolean;
    isPng: boolean;
    dsl?: DSL;
    hashImages: HashImageMap;
    vectorSvgs: VectorSvgMap;
}
export interface HashImageMap {
    [hash: string]: Uint8Array | string;
}
export interface VectorSvgMap {
    [id: string]: Uint8Array | string;
}
export interface KeyValuePair {
    key: string;
    value: string;
    description: string;
}
export interface Setting {
    userProfile?: UserProfile;
    pluginData: PluginData;
    launch: Launch;
}
export interface Launch {
    fileKey: string;
}
export interface UserProfile {
    id: string;
    name: string;
    avatarUrl: string;
    accountType: AccountType;
}
export declare enum AccountType {
    Unknown = 0,
    Google = 1,
    Form = 2
}
export interface PluginData {
    local: PluginDataLocal;
    document?: PluginDataDocument;
}
export interface PluginDataLocal {
    userId: string;
    token: string;
    language: string;
    isDebug: string;
}
export interface PluginDataDocument {
    todo: string;
}
export interface HttpbinResponse {
    arg?: any;
    headers?: any;
    origin?: string;
    url: string;
}
