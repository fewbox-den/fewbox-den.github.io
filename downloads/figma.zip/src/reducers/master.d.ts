import { Den } from '@fewbox/den';
import { Master } from './state';
declare const _default: (state: Master | undefined, action: Den.IPayload<any>) => Master;
export default _default;
