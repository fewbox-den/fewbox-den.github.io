import { Design } from './state';
declare const _default: (state: Design | undefined, action: any) => Design;
export default _default;
