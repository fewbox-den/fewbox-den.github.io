import { AppSettings } from '../reducers/state';
declare const _default: (state: AppSettings | undefined, action: any) => AppSettings;
export default _default;
