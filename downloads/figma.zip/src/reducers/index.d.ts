declare const _default: (state: any, action: any) => import("redux").CombinedState<{
    routing: unknown;
    app: import("./state").AppSettings;
    setting: import("./state").Setting;
    master: import("./state").Master;
    ajax: import("./state").Ajax;
    design: import("./state").Design;
}>;
export default _default;
