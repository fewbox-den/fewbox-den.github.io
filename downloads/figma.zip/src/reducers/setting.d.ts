import { Setting } from './state';
declare const _default: (state: Setting | undefined, action: any) => Setting;
export default _default;
