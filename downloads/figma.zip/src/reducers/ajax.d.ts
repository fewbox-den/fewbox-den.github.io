import { Ajax } from './state';
declare const _default: (state: Ajax | undefined, action: any) => Ajax;
export default _default;
