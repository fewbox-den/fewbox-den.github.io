declare const _default: import("redux-observable").Epic<import("redux").Action<any>, import("redux").Action<any>, import("../reducers/state").Store, any>;
export default _default;
