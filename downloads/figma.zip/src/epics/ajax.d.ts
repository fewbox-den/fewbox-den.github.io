import { StateObservable } from 'redux-observable';
import { Store } from '../reducers/state';
declare const _default: ((action$: any, store$: StateObservable<Store>) => any)[];
export default _default;
