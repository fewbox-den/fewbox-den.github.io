import { StateObservable } from 'redux-observable';
import { Store } from '../reducers/state';
export declare const setStorage: (key: string, value: string) => void;
export declare const setToken: (value: string) => void;
export declare const setLanguage: (language: string) => void;
export declare const setDebug: (isDebug: string) => void;
declare const _default: ((action$: any, store$: StateObservable<Store>) => any)[];
export default _default;
