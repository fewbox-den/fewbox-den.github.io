export interface FewBoxSymbol {
    readonly full: unique symbol;
}
declare class FewBoxSymbolImplement implements FewBoxSymbol {
    full: FewBoxSymbol["full"];
}
export declare const Symbol: FewBoxSymbolImplement;
export {};
