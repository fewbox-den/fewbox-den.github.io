import * as React from 'react';
import '@fewbox/den/dist/style/_boot.scss';
import '@fewbox/den/dist/style/_components.scss';
import { PluginData, Launch } from '../reducers/state';
import { PositionSetting, LayoutSetting, HashImage, AutoSizeSetting, VectorSvg, LayoutChildrenSetting } from '../figma/type';
import './App.scss';
import { GuideKeyType } from '../figma/guideStepKey';
import { DSL } from '../figma/dsl/type';
export interface IAppProps {
    pluginData: PluginData;
    launch: (launch: Launch) => void;
    initApp: () => void;
    showAlert: (alertMessage: string) => void;
    updatePluginData: (pluginData: PluginData) => void;
    updateProps: (props: string[]) => void;
    updateLayoutSetting: (layoutSetting: LayoutSetting) => void;
    updatePositionSetting: (positionSetting: PositionSetting) => void;
    updateAutoSizeSetting: (autoSizeSetting: AutoSizeSetting) => void;
    updateLayoutChildrenSetting: (layoutChildrenSetting: LayoutChildrenSetting) => void;
    updateHashImage: (hashImage: HashImage) => void;
    updateVectorSvg: (svg: VectorSvg) => void;
    generateCode: (code: string) => void;
    generateComponent: (dsl: DSL) => void;
    figmaNotify: (message: string) => void;
    highlight: (guideKey: GuideKeyType) => void;
    updateSvgExport: (isSvg: boolean) => void;
    updatePngExport: (isPng: boolean) => void;
}
export interface IAppStates {
    error: any;
    eventId: string;
}
declare class App extends React.Component<IAppProps, IAppStates> {
    constructor(props: any);
    componentDidCatch(error: any, errorInfo: any): void;
    componentDidMount(): void;
    receiveMessage(msg: any): void;
    render(): JSX.Element;
}
declare const _default: import("react-redux").ConnectedComponent<typeof App, import("react-redux").Omit<React.ClassAttributes<App> & IAppProps, "highlight" | "updateAutoSizeSetting" | "updateSvgExport" | "updatePngExport" | "updateLayoutSetting" | "updateLayoutChildrenSetting" | "updatePositionSetting" | "pluginData" | "launch" | "initApp" | "showAlert" | "updatePluginData" | "updateProps" | "updateHashImage" | "updateVectorSvg" | "generateCode" | "generateComponent" | "figmaNotify">>;
export default _default;
