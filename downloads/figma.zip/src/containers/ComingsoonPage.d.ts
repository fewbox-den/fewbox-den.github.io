import * as React from 'react';
export interface IComingsoonPageProps {
}
export interface IComingsoonPageStates {
}
declare class ComingsoonPage extends React.Component<IComingsoonPageProps, IComingsoonPageStates> {
    render(): JSX.Element;
}
export default ComingsoonPage;
