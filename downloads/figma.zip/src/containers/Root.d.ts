/// <reference types="react" />
declare const Root: () => JSX.Element;
export default Root;
