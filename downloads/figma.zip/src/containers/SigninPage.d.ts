import * as React from 'react';
export interface ISigninPageProps {
}
export interface ISigninPageStates {
}
declare class SigninPage extends React.Component<ISigninPageProps, ISigninPageStates> {
    render(): JSX.Element;
}
export default SigninPage;
