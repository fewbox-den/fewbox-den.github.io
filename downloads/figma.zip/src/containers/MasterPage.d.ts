import * as React from 'react';
import { GuideKeyType } from '../figma/guideStepKey';
export interface IMasterPageProps {
    guideKey: GuideKeyType;
    isDebug: string;
    clearHighlight: () => void;
}
export interface IMasterPageStates {
    isDebug: boolean;
}
declare class MasterPage extends React.Component<IMasterPageProps, IMasterPageStates> {
    constructor(props: any);
    render(): JSX.Element;
}
declare const _default: import("react-redux").ConnectedComponent<typeof MasterPage, import("react-redux").Omit<React.ClassAttributes<MasterPage> & IMasterPageProps, "isDebug" | "clearHighlight" | "guideKey">>;
export default _default;
