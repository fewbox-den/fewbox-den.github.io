import * as React from 'react';
import { HashImageMap, VectorSvgMap } from '../reducers/state';
import { DSL } from '../figma/dsl/type';
import { AutoSizeSetting, LayoutChildrenSetting, LayoutSetting, PositionSetting } from '../figma/type';
export interface IDesignPageProps {
    isSvg: boolean;
    isPng: boolean;
    isDebug: string;
    fileKey: string;
    dsl: DSL;
    hashImages: HashImageMap;
    vectorSvgs: VectorSvgMap;
    layoutSetting: LayoutSetting;
    positionSetting: PositionSetting;
    autoSizeSetting: AutoSizeSetting;
    layoutChildrenSetting: LayoutChildrenSetting;
    figmaSetPosition: (positionSetting: PositionSetting) => void;
    updatePositionSetting: (positionSetting: PositionSetting) => void;
    figmaSetLayout: (layoutSetting: LayoutSetting) => void;
    updateLayoutSetting: (layoutSetting: LayoutSetting) => void;
    figmaSetLayoutChildrenSetting: (layoutChildrenSetting: LayoutChildrenSetting) => void;
    updateLayoutChildrenSetting: (layoutChildrenSetting: LayoutChildrenSetting) => void;
    figmaSetAutoSize: (autoSizeSetting: AutoSizeSetting) => void;
    updateAutoSizeSetting: (autoSizeSetting: AutoSizeSetting) => void;
    figmaGenerateComponent: () => void;
    figmaNotify: (message: string) => void;
    clearComponent: () => void;
    figmaCreateDSLComponent: (dslComponent: DSL) => void;
    figmaSwichSvgExport: (isSvg: boolean) => void;
    updateSvgExport: (isSvg: boolean) => void;
    figmaSwichPngExport: (isPng: boolean) => void;
    updatePngExport: (isPng: boolean) => void;
}
export interface IDesignPageStates {
}
declare class DesignPage extends React.Component<IDesignPageProps, IDesignPageStates> {
    resetAll(): void;
    render(): JSX.Element;
}
declare const _default: import("react-redux").ConnectedComponent<typeof DesignPage, import("react-redux").Omit<React.ClassAttributes<DesignPage> & IDesignPageProps, "isDebug" | "dsl" | "autoSizeSetting" | "figmaSetAutoSize" | "updateAutoSizeSetting" | "hashImages" | "vectorSvgs" | "clearComponent" | "updateSvgExport" | "updatePngExport" | "isSvg" | "isPng" | "layoutSetting" | "layoutChildrenSetting" | "figmaSetLayout" | "figmaGenerateComponent" | "updateLayoutSetting" | "figmaSetLayoutChildrenSetting" | "updateLayoutChildrenSetting" | "positionSetting" | "figmaSetPosition" | "updatePositionSetting" | "figmaNotify" | "figmaSwichSvgExport" | "figmaSwichPngExport" | "figmaCreateDSLComponent" | "fileKey">>;
export default _default;
