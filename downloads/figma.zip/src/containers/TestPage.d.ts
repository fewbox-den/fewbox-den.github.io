import * as React from 'react';
export interface ITestPageProps {
}
export interface ITestPageStates {
}
declare class SigninPage extends React.Component<ITestPageProps, ITestPageStates> {
    render(): JSX.Element;
}
export default SigninPage;
