import * as React from 'react';
import { HttpbinResponse } from '../reducers/state';
export interface ILibPageProps {
    props: string[];
    code: string;
    token: string;
    httpbinResponse: HttpbinResponse;
    figmaSetToken: (token: string) => void;
    figmaShowProps: () => void;
    figmaNotify: (message: string) => void;
    figmaGenerateCode: () => void;
    getHttpbin: () => void;
    postHttpbin: () => void;
    putHttpbin: () => void;
    patchHttpbin: () => void;
    deleteHttpbin: () => void;
    bearerTokenHttpbin: () => void;
    status401Httpbin: () => void;
    status403Httpbin: () => void;
    status500Httpbin: () => void;
}
export interface ILibPageStates {
}
declare class LibPage extends React.Component<ILibPageProps, ILibPageStates> {
    sendNotification(message: string): void;
    render(): JSX.Element;
}
declare const _default: import("react-redux").ConnectedComponent<typeof LibPage, import("react-redux").Omit<React.ClassAttributes<LibPage> & ILibPageProps, "token" | "code" | "props" | "figmaNotify" | "figmaSetToken" | "figmaShowProps" | "figmaGenerateCode" | "getHttpbin" | "postHttpbin" | "putHttpbin" | "patchHttpbin" | "deleteHttpbin" | "bearerTokenHttpbin" | "status401Httpbin" | "status403Httpbin" | "status500Httpbin" | "httpbinResponse">>;
export default _default;
