import * as React from 'react';
import { DesignSystem } from '../figma/type';
export interface IStorePageProps {
    figmaCreateDesignSystem: (designSystem: DesignSystem) => void;
}
export interface IStorePageStates {
}
declare class StorePage extends React.Component<IStorePageProps, IStorePageStates> {
    getTypographyDescription(family: string, weight: string, size: number, letterSpacing: string): string;
    render(): JSX.Element;
}
declare const _default: import("react-redux").ConnectedComponent<typeof StorePage, import("react-redux").Omit<React.ClassAttributes<StorePage> & IStorePageProps, "figmaCreateDesignSystem">>;
export default _default;
