import * as React from 'react';
export interface ISettingPageProps {
    language: string;
    isDebug: string;
    fileKey: string;
    figmaSetLanguage: (language: string) => void;
    figmaSetDebug: (isDebug: string) => void;
}
export interface ISettingPageStates {
}
declare class SettingPage extends React.Component<ISettingPageProps, ISettingPageStates> {
    render(): JSX.Element;
}
declare const _default: import("react-redux").ConnectedComponent<typeof SettingPage, import("react-redux").Omit<React.ClassAttributes<SettingPage> & ISettingPageProps, "language" | "isDebug" | "fileKey" | "figmaSetLanguage" | "figmaSetDebug">>;
export default _default;
