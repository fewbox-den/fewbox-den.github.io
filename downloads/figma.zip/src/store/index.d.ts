declare const store: import("redux").Store<any, any> & {
    dispatch: unknown;
};
export default store;
