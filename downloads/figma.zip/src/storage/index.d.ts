export declare const setStorage: (key: string, value: string) => void;
export declare const setToken: (value: string) => void;
export declare const setLanguage: (language: string) => void;
