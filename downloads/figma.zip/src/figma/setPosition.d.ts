import { PositionSetting } from './type';
declare const _default: (positionSetting: PositionSetting) => Promise<void>;
export default _default;
