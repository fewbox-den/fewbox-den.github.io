export declare enum GuideKeyType {
    NONE = "none",
    DownloadDesignSystem = "download-design-system"
}
