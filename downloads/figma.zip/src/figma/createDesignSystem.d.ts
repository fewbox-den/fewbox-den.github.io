import { DesignSystem } from './type';
declare const _default: (designSystem: DesignSystem) => Promise<void>;
export default _default;
