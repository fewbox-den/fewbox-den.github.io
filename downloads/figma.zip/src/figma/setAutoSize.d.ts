import { AutoSizeSetting } from './type';
declare const _default: (autoSizeSetting: AutoSizeSetting) => Promise<void>;
export default _default;
