export interface PluginAPIStub {
    readonly mixed: unique symbol;
}
