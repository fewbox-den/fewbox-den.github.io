export declare enum PluginDataKeyType {
    LayoutSetting = "layout-setting",
    LayoutChildrenSetting = "layout-children-setting",
    PositionSetting = "position-setting",
    PositionAreaSetting = "position-area-setting",
    PositionAnchorPoint = "position-anchor-point",
    ResetSetting = "reset-setting",
    AutoSizeSetting = "auto-size-setting",
    DSL = "dsl"
}
