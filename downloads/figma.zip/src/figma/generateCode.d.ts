declare const _default: () => Promise<void>;
export default _default;
