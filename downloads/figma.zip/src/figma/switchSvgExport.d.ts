declare const _default: (isSvg: boolean) => Promise<void>;
export default _default;
