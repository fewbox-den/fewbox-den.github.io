import { DSL } from "./dsl/type";
declare const _default: (dsl: DSL) => Promise<void>;
export default _default;
