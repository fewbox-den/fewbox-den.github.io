declare const _default: (isPng: boolean) => Promise<void>;
export default _default;
