declare const _default: (storage: any) => Promise<void>;
export default _default;
