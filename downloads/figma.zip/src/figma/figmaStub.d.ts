/// <reference types="plugin-typings" />
import { PluginAPIStub } from './pluginAPIStub';
export declare const createFigmaStub: () => FigmaStub;
export interface FigmaStub {
    ui: any;
    mixed: PluginAPIStub['mixed'];
    getLocalPaintStyles: () => PaintStyle[];
    getLocalTextStyles: () => TextStyle[];
    getLocalEffectStyles: () => EffectStyle[];
    getLocalGridStyeles: () => GridStyle[];
    createFrame: (pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string, topLeftRadius?: number, topRightRadius?: number, bottomLeftRadius?: number, bottomRightRadius?: number) => FrameNodeStub;
    createRectangle: (pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string, topLeftRadius?: number, topRightRadius?: number, bottomLeftRadius?: number, bottomRightRadius?: number) => RectangleNodeStub;
    createEllipse: (pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string) => EllipseNodeStub;
}
export interface PluginDataStub {
    [key: string]: string;
}
declare class BaseStub {
    private pluginData;
    constructor(pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string, topLeftRadius?: number, topRightRadius?: number, bottomLeftRadius?: number, bottomRightRadius?: number);
    x: number;
    y: number;
    rotation: number;
    width: number;
    height: number;
    visible: boolean;
    locked: boolean;
    id: string;
    parent: AllNodeStub;
    name: string;
    removed: boolean;
    fillStyleId: string | PluginAPIStub['mixed'];
    strokeStyleId: string;
    fills: PluginAPIStub['mixed'] | readonly Paint[];
    strokes: readonly Paint[];
    topLeftRadius: number;
    topRightRadius: number;
    bottomLeftRadius: number;
    bottomRightRadius: number;
    exportSettings: readonly ExportSettings[];
    toString(): string;
    remove(): void;
    getPluginData(key: string): string;
    setPluginData(key: string, value: string): void;
    getSharedPluginData(namespace: string, key: string): string;
    setSharedPluginData(namespace: string, key: string, value: string): void;
    setRelaunchData(data: {
        [command: string]: string;
    }): void;
    resize(width: number, height: number): void;
    resizeWithoutConstraints(width: number, height: number): void;
    rescale(scale: number): void;
    exportAsync(settings?: ExportSettings): Promise<Uint8Array>;
    outlineStroke(): VectorNode | null;
}
declare type AllNodeStub = FrameNodeStub | RectangleNodeStub | EllipseNodeStub;
export declare class FrameNodeStub extends BaseStub {
    readonly type: 'FRAME';
    constructor(pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string, topLeftRadius?: number, topRightRadius?: number, bottomLeftRadius?: number, bottomRightRadius?: number);
    children: AllNodeStub[];
    appendChild: (child: AllNodeStub) => void;
}
export declare class EllipseNodeStub extends BaseStub {
    readonly type: 'ELLIPSE';
    constructor(pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string);
}
export declare class RectangleNodeStub extends BaseStub {
    readonly type: 'RECTANGLE';
    cornerRadius: number | PluginAPIStub['mixed'];
    cornerSmoothing: number;
    constraints: Constraints;
    removed: boolean;
    constructor(pluginData?: PluginDataStub, x?: number, y?: number, width?: number, height?: number, fillStyleId?: string, strokeStyleId?: string, topLeftRadius?: number, topRightRadius?: number, bottomLeftRadius?: number, bottomRightRadius?: number);
    reactions: readonly Reaction[];
    opacity: number;
    blendMode: "PASS_THROUGH" | BlendMode;
    isMask: boolean;
    effects: readonly Effect[];
    effectStyleId: string;
    strokeCap: PluginAPIStub['mixed'] | StrokeCap;
    strokeMiterLimit: number;
    strokeWeight: number;
    strokeJoin: PluginAPIStub['mixed'] | StrokeJoin;
    strokeAlign: "CENTER" | "INSIDE" | "OUTSIDE";
    dashPattern: readonly number[];
    strokeGeometry: VectorPaths;
    fillGeometry: VectorPaths;
    absoluteTransform: Transform;
    relativeTransform: Transform;
    absoluteRenderBounds: Rect | null;
    constrainProportions: boolean;
    layoutAlign: "CENTER" | "MIN" | "MAX" | "STRETCH" | "INHERIT";
    layoutGrow: number;
}
export declare type SceneNodeStub = RectangleNodeStub | EllipseNodeStub | FrameNodeStub;
export {};
