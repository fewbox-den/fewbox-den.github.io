declare const _default: (message: any) => Promise<void>;
export default _default;
