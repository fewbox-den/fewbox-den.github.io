import { Den } from "@fewbox/den";
import { Property } from 'csstype';
import React from "react";
import { LayoutCategory, XLayoutType, YLayoutType } from "../../type";
export interface DSLPositionAreaWrapper {
    name: string;
    _category: DSLCategory;
    positionAreaCategory: Den.Type.PositionAreaCategory;
    child: DSLAllType;
}
export interface DSLPositionWrapper {
    name: string;
    _category: DSLCategory;
    positionCategory: Den.Type.PositionCategory;
    positionType: Den.Type.PositionType;
    child: DSLAllType;
    offsetX?: number;
    offsetY?: number;
}
export declare type DSLBuildInType = DSLImage | DSLSvg | DSLOther | DSLText | DSLLine;
export declare type DSLShapeType = DSLShapeRectangle | DSLShapeEllipse;
export declare type DSLPureType = DSLBuildInType | DSLShapeType | DSLExportType | DSLTodo;
export declare type DSLContainerType = DSLPart | DSLReference | DSLGroup | DSLLayout;
export declare type DSLExportType = DSLExportSvg | DSLExportImage;
export declare type DSLActualType = DSLPureType | DSLContainerType | DSLInvisiable;
export declare type DSLVirtualType = DSLPositionAreaWrapper | DSLPositionWrapper;
export declare type DSLAllType = DSLActualType | DSLVirtualType;
export declare enum DSLCategory {
    Empty = "empty",
    Part = "part",
    ExportSvg = "export-svg",
    ExportImage = "export-image",
    VImage = "v-image",
    VText = "v-text",
    VSvg = "v-svg",
    VLine = "v-line",
    VOther = "v-other",
    Reference = "reference",
    Layout = "layout",
    Rectangle = "rectangle",
    Ellipse = "ellipse",
    Group = "group",
    PositionArea = "position-area",
    Position = "position",
    Invisiable = "invisiable"
}
export interface DSLMetaProps {
    id: string;
    name: string;
}
export interface DSLPure extends DSLMetaProps {
}
export interface DSLContainer extends DSLMetaProps {
    children: DSLAllType[];
}
export interface DSLInvisiable extends DSLPure {
    readonly _category: DSLCategory.Invisiable;
}
export interface DSLGroup extends DSLContainer {
    readonly _category: DSLCategory.Group;
}
export interface DSLPart extends DSLContainer, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps {
    readonly _category: DSLCategory.Part;
}
export interface DSLReference extends DSLPure, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps {
    readonly _category: DSLCategory.Reference;
    category: Den.Type.ImageCategory;
}
export interface DSLLayout extends DSLContainer, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps, DSLLayoutProps {
    readonly _category: DSLCategory.Layout;
}
export interface DSLImage extends DSLPure, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps {
    readonly _category: DSLCategory.VImage;
    category: Den.Type.ImageCategory;
    imageHash: string;
}
export interface DSLSvg extends DSLPure, DSLBoxProps, DSLFrontProps, DSLBorderProps {
    readonly _category: DSLCategory.VSvg;
    children: React.ReactNode;
}
export interface DSLOther extends DSLPure, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps {
    readonly _category: DSLCategory.VOther;
}
export interface DSLText extends DSLPure, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps, DSLFontProps {
    readonly _category: DSLCategory.VText;
    content: string;
}
export interface DSLLine extends DSLPure, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps, DSLFontProps {
    readonly _category: DSLCategory.VLine;
    content: string;
}
export interface DSLExportSvg extends DSLPure, DSLBoxProps, DSLFrontProps, DSLBorderProps {
    readonly _category: DSLCategory.ExportSvg;
    children: React.ReactNode;
}
export interface DSLExportImage extends DSLPure, DSLBoxProps, DSLFrontProps, DSLBorderProps {
    readonly _category: DSLCategory.ExportImage;
    children: React.ReactNode;
}
export interface DSLShape extends DSLPure, DSLBoxProps, DSLBorderProps, DSLBackgroundProps, DSLFrontProps {
}
export interface DSLShapeRectangle extends DSLShape {
    readonly _category: DSLCategory.Rectangle;
}
export interface DSLShapeEllipse extends DSLShape {
    readonly _category: DSLCategory.Ellipse;
}
export interface DSLTodo extends DSLMetaProps {
    readonly _category: DSLCategory.Empty;
}
export interface DSLBoxProps {
    width?: number;
    height?: number;
    padding?: number[];
    margin?: number[];
}
export interface DSLBorderProps {
    borderColor?: Den.Type.ColorType | string;
    borderWidth?: number;
    borderRadius?: number | number[];
}
export interface DSLFrontProps {
    frontColor?: Den.Type.ColorType | string;
}
export interface DSLBackgroundProps {
    backgroundColor?: Den.Type.ColorType | string;
}
export interface DSLFontProps {
    size?: Den.Type.SizeType;
    weight?: Den.Type.WeightType;
    letterSpacing?: number;
    lineHeight?: number;
    transform?: string;
    decoration?: string;
}
export interface DSLLayoutProps {
    category: LayoutCategory;
    xLayout?: XLayoutType;
    yLayout?: YLayoutType;
    gap?: number;
}
declare type TLength = (string & {}) | 0;
export interface DSLElementFrontProps {
    frontColor?: Den.Type.ColorType;
}
export interface DSLElementBackgroundProps {
    backgroundColor?: Den.Type.ColorType;
}
export interface DSLElementFontProps {
    size?: Den.Type.SizeType;
}
export interface DSLElementBoxProps {
    width?: Property.Height<TLength>;
    height?: Property.Height<TLength>;
    padding?: Property.Padding<TLength>;
    margin?: Property.Margin<TLength>;
}
export interface DSLElementBorderProps {
    borderColor?: Den.Type.ColorType | string;
    borderWidth?: Property.Height<TLength>;
    borderRadius?: Property.BorderRadius;
    borderStyle?: Property.BorderStyle;
}
export interface DSLElementLayoutProps {
    gap?: string;
    cross?: Den.Type.XCrossType | Den.Type.YCrossType;
}
export interface DSLElementPositionProps {
    positionCategory?: Den.Type.PositionCategory;
    positionType?: Den.Type.PositionType;
    offsetX?: number;
    offsetY?: number;
}
export interface DSLElementPositionAreaProps {
    positionAreaCategory?: Den.Type.PositionAreaCategory;
}
export interface DSLElementProps extends DSLElementBoxProps, DSLElementBorderProps, DSLFrontProps, DSLBackgroundProps, DSLFontProps, DSLElementLayoutProps, DSLElementPositionProps, DSLElementPositionAreaProps {
    name: string;
}
export interface DSLElementSelfPostionProps {
    category: Den.Type.PositionCategory;
    type?: Den.Type.PositionType;
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
    zIndex?: number;
}
export interface DSLCharacter {
    characters: string;
}
export interface DSLMeta {
    id: string;
    name: string;
    visible: boolean;
    type: string;
}
export interface DSLStroke {
    color: Den.Type.ColorType | string | undefined;
    width: number | undefined;
    radius: number | number[] | undefined;
}
export interface DSLFill {
    color: Den.Type.ColorType | string | undefined;
}
export interface DSLExportItem {
    type: string;
}
export interface DSLExport {
    items: DSLExportItem[];
}
export interface DSLPostion {
    x: number;
    y: number;
}
export interface DSLSize {
    width: number;
    height: number;
}
export interface DSLDeg {
    rotation: number;
}
export interface DSLFont {
    size: Den.Type.SizeType;
    weight?: Den.Type.WeightType;
    letterSpacing?: number;
    lineHeight?: number;
    transform?: string;
    decoration?: string;
    characters: string;
}
export interface DSLZone extends DSLPostion, DSLSize {
}
export interface DSLJSX {
    jsxElement: JSX.Element;
    jsxString: string;
}
export interface DSLJSXCollection {
    jsxElements: JSX.Element[];
    jsxString: string;
}
export interface DSLLibSystem {
    components: DSLAllType[];
}
export interface DSL {
    libSystem: DSLLibSystem;
}
export {};
