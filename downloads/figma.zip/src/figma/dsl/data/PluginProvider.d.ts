/// <reference types="plugin-typings" />
import { PluginDataKeyType } from "../../PluginDataKey";
import { FigmaAllNode, FigamSvgNode, FigmaDesignSystem } from "../../type";
import { DSLAllType, DSLExport, DSLFont, DSLImage } from "../type";
import { IPluginProvider } from "./IPluginProvider";
export declare abstract class PluginProvider implements IPluginProvider<FigmaAllNode> {
    isContainer: (node: FigmaAllNode, callback: (node: any) => void) => void;
    isAll: (node: FigmaAllNode, callback: (node: any) => void) => void;
    isRadius: (node: FigmaAllNode, callback: (node: any) => void) => void;
    isFourCornerRadius: (node: FigmaAllNode, callback: (node: any) => void) => void;
    isSpecial: (node: FigmaAllNode, callback: (node: any) => void) => void;
    isNormal: (node: FigmaAllNode, callback: (node: any) => void) => void;
    isImage: (node: FigmaAllNode, callback: (node: any) => void) => void;
    getChildrenZone: (node: FigmaAllNode) => any;
    getParentZone: (node: FigmaAllNode) => {
        x: number;
        y: number;
        width: number;
        height: number;
    } | undefined;
    getCurrentZone: (node: FigmaAllNode) => {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    getSize: (node: FigmaAllNode) => {
        width: number;
        height: number;
    };
    getFont: (node: TextNode, figmaDesignSystem: FigmaDesignSystem) => DSLFont;
    getStroke: (node: FigmaAllNode, figmaDesignSystem: FigmaDesignSystem) => {
        color: string | undefined;
        width: number | undefined;
        radius: number | number[] | undefined;
    };
    getFill: (node: FigmaAllNode, figmaDesignSystem: FigmaDesignSystem) => {
        color: string | undefined;
    };
    getExport: (node: FigmaAllNode) => DSLExport;
    getExportImage: (node: FigmaAllNode) => void;
    getMeta: (node: SceneNode) => {
        id: string;
        name: string;
        visible: boolean;
        type: "BOOLEAN_OPERATION" | "COMPONENT" | "ELLIPSE" | "FRAME" | "INSTANCE" | "LINE" | "POLYGON" | "RECTANGLE" | "STAR" | "TEXT" | "VECTOR" | "GROUP" | "SLICE" | "COMPONENT_SET" | "STICKY" | "CONNECTOR" | "SHAPE_WITH_TEXT" | "CODE_BLOCK" | "STAMP" | "WIDGET" | "EMBED" | "LINK_UNFURL";
    };
    getSvg: (node: FigamSvgNode) => void;
    getDeg: (node: LineNode) => {
        rotation: number;
    };
    getChildren: (node: FigmaAllNode, figmaDesignSystem: FigmaDesignSystem) => DSLAllType[];
    getImage: (node: FigmaAllNode, figmaDesignSystem: FigmaDesignSystem) => DSLImage | undefined;
    getCharacter: (node: TextNode) => {
        characters: string;
    };
    getData: <T>(node: SceneNode, key: PluginDataKeyType) => T;
    abstract getFigma: () => any;
}
