/// <reference types="plugin-typings" />
import { PluginProvider } from "./PluginProvider";
export declare class FigmaPluginProvider extends PluginProvider {
    getFigma: () => PluginAPI;
}
