import { PluginProvider } from "./PluginProvider";
export declare class FigmaPluginStubProvider extends PluginProvider {
    getFigma: () => import("../../figmaStub").FigmaStub;
}
