import { FigmaDesignSystem } from "../../type";
import { DSLStroke, DSLSize, DSLZone, DSLFill, DSLMeta, DSLFont, DSLDeg, DSLCharacter, DSLImage, DSLAllType, DSLExport } from "../type";
export interface IPluginProvider<N> {
    getChildren: (node: N, figmaDesignSystem: FigmaDesignSystem) => DSLAllType[];
    getSvg: (node: N) => void;
    getData: <T>(node: N, key: string) => T;
    getDeg: (node: N) => DSLDeg;
    getSize: (node: N) => DSLSize;
    getFont: (node: N, figmaDesignSystem: FigmaDesignSystem) => DSLFont;
    getStroke: (node: N, figmaDesignSystem: FigmaDesignSystem) => DSLStroke;
    getFill: (node: N, figmaDesignSystem: FigmaDesignSystem) => DSLFill;
    getExport: (node: N) => DSLExport;
    getExportImage: (node: N) => void;
    getMeta: (node: N) => DSLMeta;
    getCharacter: (node: N) => DSLCharacter;
    getCurrentZone: (node: N) => DSLZone;
    getParentZone: (node: N) => DSLZone | undefined;
    getChildrenZone: (node: N) => DSLZone | undefined;
    getImage: (node: N, figmaDesignSystem: FigmaDesignSystem) => DSLImage | undefined;
    isContainer: (node: N, callback: (node: N) => void) => void;
    isAll: (node: N, callback: (node: N) => void) => void;
    isRadius: (node: N, callback: (node: N) => void) => void;
    isFourCornerRadius: (node: N, callback: (node: N) => void) => void;
    isSpecial: (node: N, callback: (node: N) => void) => void;
    isNormal: (node: N, callback: (node: N) => void) => void;
    isImage: (node: N, callback: (node: N) => void) => void;
}
