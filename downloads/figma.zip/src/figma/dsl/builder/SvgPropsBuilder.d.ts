import BasePropsBuilder from './BasePropsBuilder';
export default class SvgPropsBuilder<N> extends BasePropsBuilder<N> {
    buildSvg(): void;
}
