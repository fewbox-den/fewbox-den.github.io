import BasePropsBuilder from './BasePropsBuilder';
export default class ShapePropsBuilder<N> extends BasePropsBuilder<N> {
    buildBox(): void;
}
