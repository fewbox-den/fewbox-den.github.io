import { DSLCategory, DSLActualType } from '../type';
export default interface PropsBuilder {
    buildBox(): void;
    buildBorder(): void;
    buildFront(): void;
    buildBackground(): void;
    buildFont(): void;
    buildLayout(): void;
    buildSvg(): void;
    buildImage(): void;
    getRender(_category: DSLCategory): DSLActualType;
}
