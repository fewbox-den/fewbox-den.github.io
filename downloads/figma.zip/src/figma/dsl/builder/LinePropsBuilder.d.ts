import BasePropsBuilder from './BasePropsBuilder';
export default class LinePropsBuilder<N> extends BasePropsBuilder<N> {
    buildBox(): void;
    buildFront(): void;
    buildSvg(): void;
}
