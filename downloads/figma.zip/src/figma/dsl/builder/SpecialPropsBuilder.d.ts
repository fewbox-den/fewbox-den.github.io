import { IPluginProvider } from '../data/IPluginProvider';
import NodeProcessContext from '../NodeProcessContext';
import { DSLActualType } from '../type';
import PropsBuilder from './PropsBuilder';
export default class SpecialPropsBuilder<N> implements PropsBuilder {
    protected context: NodeProcessContext<N>;
    protected pluginProvider: IPluginProvider<N>;
    constructor(context: NodeProcessContext<N>, pluginDataProvider: IPluginProvider<N>);
    buildLayout(): void;
    buildBox(): void;
    buildBorder(): void;
    buildFront(): void;
    buildBackground(): void;
    buildFont(): void;
    buildSvg(): void;
    buildImage(): void;
    getRender<T extends DSLActualType>(extendProps: any): DSLActualType;
}
