import BasePropsBuilder from './BasePropsBuilder';
export default class TextPropsBuilder<N> extends BasePropsBuilder<N> {
    buildFont(): void;
}
