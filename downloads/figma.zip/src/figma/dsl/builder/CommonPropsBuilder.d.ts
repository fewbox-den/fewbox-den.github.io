import BasePropsBuilder from './BasePropsBuilder';
export default class CommonPropsBuilder<N> extends BasePropsBuilder<N> {
}
