import BasePropsBuilder from './BasePropsBuilder';
export default class PngPropsBuilder<N> extends BasePropsBuilder<N> {
    buildBox(): void;
    buildImage(): void;
}
