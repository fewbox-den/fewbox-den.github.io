import BasePropsBuilder from './BasePropsBuilder';
export default class FillPropsBuilder<N> extends BasePropsBuilder<N> {
    buildBox(): void;
}
