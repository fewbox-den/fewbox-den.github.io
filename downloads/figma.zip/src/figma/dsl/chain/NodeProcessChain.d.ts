import { DSLAllType } from "../type";
import NodeProcessContext from "../NodeProcessContext";
import { IPluginProvider } from "../data/IPluginProvider";
export default class NodeProcessChain<T> {
    private static instance;
    private rootNodeHandler;
    private constructor();
    static getInstance<N>(pluginProvider: IPluginProvider<N>): NodeProcessChain<any>;
    process: (context: NodeProcessContext<T>) => DSLAllType;
}
