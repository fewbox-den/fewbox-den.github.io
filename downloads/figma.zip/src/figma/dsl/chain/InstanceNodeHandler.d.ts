import { DSLAllType } from "../type";
import BaseNodeHandler from "./BaseNodeHandler";
import NodeProcessContext from "../NodeProcessContext";
export default class InstanceNodeHandler<N> extends BaseNodeHandler<N> {
    wrap: (context: NodeProcessContext<N>) => DSLAllType;
    process: (context: NodeProcessContext<N>) => DSLAllType;
}
