import NodeProcessContext from "../NodeProcessContext";
import { DSLAllType } from "../type";
export default interface NodeHandler<T> {
    successor: NodeHandler<any>;
    process: (context: NodeProcessContext<T>) => DSLAllType;
}
