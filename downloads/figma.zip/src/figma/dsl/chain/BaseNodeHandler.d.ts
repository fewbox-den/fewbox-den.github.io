import { IPluginProvider } from "../data/IPluginProvider";
import NodeProcessContext from "../NodeProcessContext";
import { DSLAllType } from "../type";
import Wrapper from "../wrapper/Wrapper";
import NodeHandler from "./NodeHandler";
export default abstract class BaseNodeHandler<N> implements NodeHandler<N>, Wrapper<N> {
    successor: NodeHandler<any>;
    abstract process: (context: NodeProcessContext<N>) => DSLAllType;
    abstract wrap: (context: NodeProcessContext<N>) => DSLAllType;
    protected pluginProvider: IPluginProvider<N>;
    constructor(pluginProvider: IPluginProvider<N>);
}
