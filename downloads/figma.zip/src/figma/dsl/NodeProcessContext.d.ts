import { FigmaDesignSystem } from "../type";
export default interface NodeProcessContext<N> {
    node: N;
    figmaDesignSystem: FigmaDesignSystem;
}
