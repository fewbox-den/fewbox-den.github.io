import NodeProcessContext from "../NodeProcessContext";
import { DSLAllType } from "../type";
export default interface Wrapper<N> {
    wrap: (context: NodeProcessContext<N>) => DSLAllType;
}
