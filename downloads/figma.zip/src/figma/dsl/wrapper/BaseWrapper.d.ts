import { IPluginProvider } from "../data/IPluginProvider";
import NodeProcessContext from "../NodeProcessContext";
import { DSLAllType } from "../type";
import Wrapper from "./Wrapper";
export default abstract class BaseNodeHandlerWrapper<N> implements Wrapper<N> {
    wrapper: Wrapper<N>;
    protected pluginProvider: IPluginProvider<N>;
    constructor(wrapper: Wrapper<N>, pluginProvider: IPluginProvider<N>);
    abstract wrap: (context: NodeProcessContext<N>) => DSLAllType;
}
