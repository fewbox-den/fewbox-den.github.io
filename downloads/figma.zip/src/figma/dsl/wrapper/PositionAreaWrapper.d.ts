import NodeProcessContext from "../NodeProcessContext";
import { DSLAllType } from "../type";
import BaseNodeHandlerWrapper from "./BaseWrapper";
export default class PositionAreaWrapper<N> extends BaseNodeHandlerWrapper<N> {
    wrap: (context: NodeProcessContext<N>) => DSLAllType;
}
