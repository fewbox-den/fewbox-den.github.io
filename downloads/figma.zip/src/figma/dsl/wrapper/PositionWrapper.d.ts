import NodeProcessContext from "../NodeProcessContext";
import { DSLAllType } from "../type";
import BaseNodeHandlerWrapper from "./BaseWrapper";
export default class PositionWrapper<N> extends BaseNodeHandlerWrapper<N> {
    wrap: (context: NodeProcessContext<N>) => DSLAllType;
}
