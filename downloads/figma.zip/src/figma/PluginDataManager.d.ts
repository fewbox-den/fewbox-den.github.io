/// <reference types="plugin-typings" />
export default class PluginDataManager {
    data: any;
    figma: PluginAPI;
    constructor(figma: PluginAPI);
    private updatePluginDataToUI;
    refreshPluginData(): Promise<void>;
    updateLocalDataField(name: string, value: string): Promise<void>;
    fetchAndSyncLocalData(): Promise<void>;
    saveLocalData(): Promise<void>;
    updateDocumentDataField(name: string, value: string): boolean;
    fetchAndSyncDocumentData(): boolean;
    saveDocumentData(): boolean;
}
