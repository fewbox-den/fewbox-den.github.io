import { LayoutChildrenSetting } from './type';
declare const _default: (layoutChildrenSetting: LayoutChildrenSetting) => Promise<void>;
export default _default;
