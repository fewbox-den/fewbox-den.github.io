/// <reference types="plugin-typings" />
import { Den } from "@fewbox/den";
import { KeyValuePair } from "../../reducers/state";
export interface FigmaColorSystem {
    styles: PaintStyle[];
}
export interface FigmaTypographySystem {
    styles: TextStyle[];
}
export interface FigmaEffectSystem {
    styles: EffectStyle[];
}
export interface FigmaGridSystem {
    styles: GridStyle[];
}
export interface Colors {
    [name: string]: KeyValuePair;
}
export interface DesignSystem {
    colorSystem: ColorSystem;
    typographySystem: TypographySystem;
}
export interface TypographySystem {
    typographies: DesignSystemTypography[];
}
export interface DesignSystemTypography {
    name: string;
    description: string;
    fontSize: number;
    weight: string;
}
export interface ColorSystem {
    colors: DesignSystemColor[];
}
export interface DesignSystemColor {
    name: string;
    description: string;
    value: string;
}
export interface FigmaDesignSystem {
    colorSystem: FigmaColorSystem;
    typographySystem: FigmaTypographySystem;
    effectSystem: FigmaEffectSystem;
    gridSystem: FigmaGridSystem;
}
export declare enum AutoSizeCategory {
    NONE = "none",
    Padding = "padding",
    Margin = "margin",
    All = "all"
}
export interface AutoSizeSetting {
    category: AutoSizeCategory;
}
export interface HashImage {
    hash: string;
    bytes: Uint8Array;
}
export interface VectorSvg {
    id: string;
    bytes: Uint8Array;
}
export declare enum LayoutCategory {
    X = "x",
    Y = "y",
    NONE = "none"
}
export declare enum LayoutType {
    FixedFixed = "fixed-fixed",
    FixedAuto = "fixed-auto",
    AutoFixed = "auto-fixed",
    AutoAuto = "auto-auto",
    FullFixed = "full-fixed",
    FullAuto = "full-auto",
    NONE = "none"
}
export declare enum XLayoutType {
    Around = "around",
    AutoBoth = "auto-both",
    AutoCenter = "auto-center",
    AutoLeft = "auto-left",
    AutoLefts = "auto-lefts",
    AutoRight = "auto-right",
    AutoRights = "auto-rights",
    Between = "between",
    Center = "center",
    Custom = "custom",
    CustomBoth = "custom-both",
    Evenly = "evenly",
    Left = "left",
    Right = "right",
    Wrap = "wrap",
    WrapAround = "wrap-around",
    WrapBetween = "wrap-between",
    WrapBottom = "wrap-bottom",
    WrapEvenly = "wrap-evenly",
    WrapMiddle = "wrap-middle",
    WrapTop = "wrap-top",
    Stretch = "stretch",
    FullSize = "full-size",
    Reset = "reset"
}
export declare enum YLayoutType {
    Between = "between",
    Middle = "middle",
    Top = "top",
    Bottom = "bottom",
    Around = "around",
    Evenly = "evenly",
    Stretch = "stretch",
    FullSize = "full-size",
    Reset = "reset"
}
export interface PositionAreaSetting {
    category?: Den.Type.PositionAreaCategory;
}
export interface LayoutChildrenSetting {
    order: LayoutChildrenOrder;
}
export declare enum LayoutChildrenOrder {
    Normal = "normal",
    Reverse = "reverse"
}
export interface LayoutSetting {
    category: LayoutCategory;
    type: LayoutType;
    xLayout?: XLayoutType;
    yLayout?: YLayoutType;
    space?: number;
    padding?: number;
}
export interface PositionSetting {
    category?: Den.Type.PositionCategory;
    position?: Den.Type.PositionType;
}
export interface ResetSetting {
    items: Item[];
}
export interface Item {
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface Postion {
    x: number;
    y: number;
}
export declare type FigmaContainerNode = FrameNode | InstanceNode | ComponentNode | GroupNode;
export declare type FigmaNormalNode = BooleanOperationNode | ComponentNode | EllipseNode | FrameNode | InstanceNode | LineNode | PolygonNode | RectangleNode | StarNode | TextNode | VectorNode;
export declare type FigmaSpecialNode = GroupNode;
export declare type FigmaAllNode = FigmaNormalNode | FigmaSpecialNode;
export declare type FigmaRadiusNode = BooleanOperationNode | ComponentNode | FrameNode | InstanceNode | RectangleNode | EllipseNode;
export declare type FigmaFourCornerRadiusNode = ComponentNode | FrameNode | InstanceNode | RectangleNode;
export declare type FigmaMarginNode = BooleanOperationNode | ComponentNode | EllipseNode | FrameNode | InstanceNode | LineNode | PolygonNode | RectangleNode | StarNode | TextNode | VectorNode;
export declare type FigmaPaddingNode = FrameNode;
export declare type FigmaBackgroundNode = BooleanOperationNode | ComponentNode | EllipseNode | FrameNode | InstanceNode | PolygonNode | RectangleNode | StarNode | VectorNode;
export declare type FigmaFrontNode = LineNode | TextNode;
export declare type FigmaFontSizeNode = TextNode;
export declare type FigmaImageNode = EllipseNode | RectangleNode;
export declare type FigamSvgNode = BooleanOperationNode | LineNode | PolygonNode | StarNode | VectorNode;
export declare const FigmaNormalNodeType: string[];
export declare const FigmaSpecialNodeType: string[];
export declare const FigmaAllNodeType: string[];
export declare const FigmaRadiusNodeType: string[];
export declare const FigmaFourCornerRadiusNodeType: string[];
export declare const FigmaMarginNodeType: string[];
export declare const FigmaPaddingNodeTypes: string[];
export declare const FigmaBackgroundNodeType: string[];
export declare const FigmaFrontNodeType: string[];
export declare const FigmaFontSizeNodeType: string[];
export declare const FigmaImageNodeType: string[];
export declare const FigmaDSLSvgNodeType: string[];
export declare const FigmaContainerNodeType: string[];
