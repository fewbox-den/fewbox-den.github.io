declare const _default: (key: any, value: any, storage: any) => Promise<void>;
export default _default;
