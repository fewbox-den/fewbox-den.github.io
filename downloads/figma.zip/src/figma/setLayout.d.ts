import { LayoutSetting } from './type';
declare const _default: (layoutSetting: LayoutSetting) => Promise<void>;
export default _default;
