declare const _default: (id: string) => Promise<void>;
export default _default;
