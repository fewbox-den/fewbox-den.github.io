/// <reference types="plugin-typings" />
import { PluginDataKeyType } from "../PluginDataKey";
export declare const getPluginDataDefaultValue: (pluginDataKeyType: PluginDataKeyType) => any;
export declare const getPluginData: <T>(node: SceneNode, pluginDataKeyType: PluginDataKeyType) => T;
export declare const setPluginData: <T>(pluginDataKeyType: PluginDataKeyType, value: T, node: BaseNode | null) => void;
export declare const clearPluginData: (pluginDataKeyType: PluginDataKeyType, node: BaseNode | null) => void;
