export declare const getPixelString: (value?: number | undefined) => string | undefined;
export declare const getPixelStrings: (values?: number[] | undefined) => string | undefined;
export declare const getIncludeZeroPixelString: (value?: number | undefined) => string | undefined;
