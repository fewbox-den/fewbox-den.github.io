import { FigamSvgNode } from "../type";
export declare const getSvgData: (node: FigamSvgNode) => Promise<Uint8Array>;
