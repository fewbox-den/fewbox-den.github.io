import { FigmaAllNode } from "../type";
export declare const getImageUrl: (hash: string) => Promise<Uint8Array>;
export declare const getImageData: (node: FigmaAllNode) => Promise<Uint8Array>;
