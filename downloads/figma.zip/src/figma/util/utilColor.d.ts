/// <reference types="plugin-typings" />
export declare const hexToRgb: (hex: string) => RGB | null;
export declare const rgbSegmentToHex: (segment: number) => string;
export declare const rgbToHex: (color: RGB) => string;
export declare const hexToRgba: (hex: string) => {
    r: number;
    g: number;
    b: number;
    a: number;
} | null;
