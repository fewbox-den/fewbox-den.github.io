import './simulator.scss';
