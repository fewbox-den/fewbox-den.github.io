import * as React from 'react';
import './index.scss';
export interface IAnchorPointLinkProps {
    to: string;
}
export default class AnchorPointLink extends React.PureComponent<IAnchorPointLinkProps> {
    render(): JSX.Element;
}
