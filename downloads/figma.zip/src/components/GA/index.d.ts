import { Den } from '@fewbox/den';
import * as React from 'react';
export interface IGAProps {
    trackingId: string;
    app: string;
    version: string;
    isTestMode?: boolean;
    options?: Den.IGA4Options;
    isDebug?: boolean;
}
export declare const GA: React.FC<IGAProps>;
export default GA;
