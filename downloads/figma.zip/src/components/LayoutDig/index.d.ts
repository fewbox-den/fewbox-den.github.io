/// <reference types="react" />
import { Den } from '@fewbox/den';
import { XLayoutType, LayoutSetting, LayoutCategory, YLayoutType, LayoutChildrenSetting, LayoutType } from '../../figma/type';
import './index.scss';
export interface ILayoutDigProps extends Den.IVProps {
    layoutSetting: LayoutSetting;
    layoutChildrenSetting: LayoutChildrenSetting;
    figmaSetLayout: (layoutSetting: LayoutSetting) => void;
    figmaGenerateComponent: () => void;
    updateLayoutSetting: (layoutSetting: LayoutSetting) => void;
    figmaSetLayoutChildrenSetting: (layoutChildrenSetting: LayoutChildrenSetting) => void;
    updateLayoutChildrenSetting: (layoutChildrenSetting: LayoutChildrenSetting) => void;
}
export interface ILayoutDigStates extends Den.IVStates {
}
export default class LayoutDig extends Den.Components.VBase<ILayoutDigProps, ILayoutDigStates> {
    constructor(props: any);
    selectLayout(layoutCategory: LayoutCategory, xLayout: XLayoutType, yLayout: YLayoutType): void;
    getSelectedLayoutColor(layoutCategory: LayoutCategory, xLayout: XLayoutType, yLayout: YLayoutType): import("@fewbox/den/dist/src/components").ColorType.Primary | import("@fewbox/den/dist/src/components").ColorType.Placeholder;
    renderBoundary(layoutCategory: LayoutCategory, xLayout: XLayoutType, yLayout: YLayoutType, children: JSX.Element, isComingsoon?: boolean): JSX.Element;
    changeSpace(e: any): void;
    changePadding(e: any): void;
    changeType(layoutType: LayoutType): void;
    changeLayoutChildrenSetting(): void;
    resetLayout(): void;
    render(): JSX.Element;
}
