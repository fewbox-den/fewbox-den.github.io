/// <reference types="react" />
import { Den } from '@fewbox/den';
import './index.scss';
export declare enum DigPartCategory {
    X = "x",
    Y = "y",
    YFullWidth = "y-full-size",
    YStretch = "y-stretch"
}
export interface IDigPartProps extends Den.IVProps {
    category?: DigPartCategory;
    content?: string;
}
export default class DigPart extends Den.Components.VBase<IDigPartProps> {
    render(): JSX.Element;
}
