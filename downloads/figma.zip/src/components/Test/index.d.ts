/// <reference types="react" />
export interface ITestProps {
}
export default function Test(props: ITestProps): JSX.Element;
