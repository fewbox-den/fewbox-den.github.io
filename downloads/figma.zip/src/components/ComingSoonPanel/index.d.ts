import * as React from 'react';
export interface IComingSoonPanelProps {
}
export interface IComingSoonPanelStates {
    isOpen: boolean;
}
export default class ComingSoonPanel extends React.PureComponent<IComingSoonPanelProps, IComingSoonPanelStates> {
    constructor(props: any);
    tagglePanel(): void;
    render(): JSX.Element;
}
