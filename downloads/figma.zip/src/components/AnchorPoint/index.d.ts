import * as React from 'react';
export interface IAnchorPointProps {
    anchor: string;
}
export default class AnchorPoint extends React.PureComponent<IAnchorPointProps> {
    render(): JSX.Element;
}
