/// <reference types="react" />
import { Den } from '@fewbox/den';
export interface IExportImageDigProps extends Den.IVProps {
    figmaSwitchSvgExport: (isSvg: boolean) => void;
    updateSvgExport: (isSvg: boolean) => void;
    figmaSwitchPngExport: (isPng: boolean) => void;
    updatePngExport: (isPng: boolean) => void;
    isSvg: boolean;
    isPng: boolean;
}
export default class ExportImageDig extends Den.Components.VBase<IExportImageDigProps> {
    switchSvgExport(): void;
    switchPngExport(): void;
    render(): JSX.Element;
}
