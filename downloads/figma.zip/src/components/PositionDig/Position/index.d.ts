/// <reference types="react" />
import { Den } from '@fewbox/den';
import './index.scss';
export interface IPositionDigPositonProps extends Den.IVProps {
}
export default class PositionDigPositon extends Den.Components.VBase<IPositionDigPositonProps> {
    render(): JSX.Element;
}
