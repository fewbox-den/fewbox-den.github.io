/// <reference types="react" />
import { Den } from '@fewbox/den';
import './index.scss';
export interface IPositionDigCategoryProps extends Den.IVProps {
}
export default class PositionDigCategory extends Den.Components.VBase<IPositionDigCategoryProps> {
    render(): JSX.Element;
}
