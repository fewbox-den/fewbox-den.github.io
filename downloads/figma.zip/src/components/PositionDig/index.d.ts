/// <reference types="react" />
import { Den } from '@fewbox/den';
import { PositionSetting } from '../../figma/type';
export interface IPositionDigProps extends Den.IVProps {
    positionSetting?: PositionSetting;
    figmaSetPosition: (positionSetting: PositionSetting) => void;
    updatePositionSetting: (positionSetting: PositionSetting) => void;
}
export interface IPositionDigStates extends Den.IVStates {
}
export default class PositionDig extends Den.Components.VBase<IPositionDigProps, IPositionDigStates> {
    selectCategory(category: Den.Type.PositionCategory): void;
    selectPosition(position: Den.Type.PositionType): void;
    resetPosition(): void;
    render(): JSX.Element;
}
