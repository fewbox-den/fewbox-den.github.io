import * as React from 'react';
export interface IShortcutProps {
    resetAll: () => void;
    figmaGenerateComponent: () => void;
}
export default class Shortcut extends React.PureComponent<IShortcutProps> {
    render(): JSX.Element;
}
