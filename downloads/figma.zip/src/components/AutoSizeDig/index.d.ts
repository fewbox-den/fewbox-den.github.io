/// <reference types="react" />
import { Den } from '@fewbox/den';
import { AutoSizeCategory, AutoSizeSetting } from '../../figma/type';
export interface IAutoSizeDigProps extends Den.IVProps {
    autoSizeSetting: AutoSizeSetting;
    figmaSetAutoSize: (autoSizeSetting: AutoSizeSetting) => void;
    updateAutoSizeSetting: (autoSizeSetting: AutoSizeSetting) => void;
}
export default class AutoSizeDig extends Den.Components.VBase<IAutoSizeDigProps> {
    selectAutoSize(category: AutoSizeCategory): void;
    resetAutoSize(): void;
    render(): JSX.Element;
}
