import { HashImageMap, VectorSvgMap } from '../../reducers/state';
import { DSLAllType, DSLJSX } from '../../figma/dsl/type';
export declare const parseComponent: (dsl: DSLAllType, hashImages: HashImageMap, vectorSvgs: VectorSvgMap, keyPrefix: string, keyIndex?: number | undefined) => DSLJSX;
