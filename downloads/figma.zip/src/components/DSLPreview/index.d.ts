/// <reference types="react" />
import { Den } from '@fewbox/den';
import { HashImageMap, VectorSvgMap } from '../../reducers/state';
import { DSL } from '../../figma/dsl/type';
export interface IDSLPreviewProps extends Den.IVProps {
    isDebug: boolean;
    dsl: DSL;
    hashImages: HashImageMap;
    vectorSvgs: VectorSvgMap;
    clearComponent: () => void;
    createDSLComponent: (dslComponent: DSL) => void;
    notifyCallback: (message: string) => void;
}
export interface IDSLPreviewStates extends Den.IVStates {
    scale: number;
}
export default class DSLPreview extends Den.Components.VBase<IDSLPreviewProps, IDSLPreviewStates> {
    constructor(props: any);
    changeScale(e: any): void;
    createDSLComponent(): void;
    render(): JSX.Element;
}
