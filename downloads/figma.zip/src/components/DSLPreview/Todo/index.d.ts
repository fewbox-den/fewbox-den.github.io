import * as React from 'react';
export interface IDSLPreviewTodoProps {
    content: string | JSX.Element;
}
export default class DSLPreviewTodo extends React.PureComponent<IDSLPreviewTodoProps> {
    render(): JSX.Element;
}
