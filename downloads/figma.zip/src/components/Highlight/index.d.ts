import { Den } from '@fewbox/den';
import * as React from 'react';
import './index.scss';
export interface IHighlightProps extends Den.IVProps {
    isMatch: boolean;
    clearHighlight: () => void;
}
export default class Highlight extends Den.Components.VBase<IHighlightProps> {
    render(): React.ReactNode;
}
