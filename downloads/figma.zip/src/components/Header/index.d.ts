import * as React from 'react';
import { GuideKeyType } from '../../figma/guideStepKey';
export interface IHeaderProps {
    guideKey: GuideKeyType;
    clearHighlight: () => void;
}
export default class Header extends React.PureComponent<IHeaderProps> {
    render(): JSX.Element;
}
