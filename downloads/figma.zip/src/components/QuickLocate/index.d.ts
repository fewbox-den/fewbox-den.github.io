import * as React from 'react';
export interface IQuickLocateProps {
}
export default class QuickLocate extends React.PureComponent<IQuickLocateProps> {
    render(): JSX.Element;
}
